
from pyrogram import Client, filters
import random

slaps = [
    "slapped {user} with a pillow! 😹",
    "gave a tight slap to {user}! 😤",
    "slapped {user} with love 💋"
]

punches = [
    "punched {user} like a boxer! 🥊",
    "knocked out {user} with a single punch 💥",
    "hit {user} with anime power! 🔥"
]

@Client.on_message(filters.command("slap") & filters.reply)
async def slap(_, message):
    victim = message.reply_to_message.from_user.first_name
    await message.reply_text(random.choice(slaps).format(user=victim))

@Client.on_message(filters.command("punch") & filters.reply)
async def punch(_, message):
    victim = message.reply_to_message.from_user.first_name
    await message.reply_text(random.choice(punches).format(user=victim))
