
from pyrogram import Client, filters
import random

love_quotes = [
    "You make my world bright ❤️",
    "You're the sunshine in my life ☀️",
    "You're my person 💞",
    "Love is in the air, especially with you around 💖"
]

@Client.on_message(filters.command("love") & filters.group)
async def love(_, message):
    await message.reply_text(random.choice(love_quotes))
