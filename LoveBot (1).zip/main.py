
from config import API_ID, API_HASH, BOT_TOKEN, OWNER_ID, MONGO_URI
from pyrogram import Client, filters
from plugins import love, fun
from pymongo import MongoClient

app = Client("LoveBot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)
mongo = MongoClient(MONGO_URI)
db = mongo['love_bot']

if __name__ == "__main__":
    print("Love Bot is Running...")
    app.run()
