
API_ID = 10658015
API_HASH = "a0087bca748f86698c53d291c9e5b3af"
BOT_TOKEN = "7808483233:AAFDNr1xW2fv112Hik7dM2Bh_wrVdDVktUM"
MONGO_URI = "mongodb+srv://hinfi933:4kikA8i7RDzVsB1B@cluster0.xjntjrp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
OWNER_ID = 7657218453
